export interface MudancaDetectada {
  codigo: string | number;
  campo: string;
  valorAnterior: string;
  valorNovo: string;
}